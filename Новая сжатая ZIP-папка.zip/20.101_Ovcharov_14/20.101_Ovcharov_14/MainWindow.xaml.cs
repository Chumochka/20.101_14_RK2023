﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;
using _20._101_Ovcharov_14.Entities;

namespace _20._101_Ovcharov_14
{
    /// <summary>
    /// Логика взаимодействия для MainWindow.xaml
    /// </summary>
    public partial class MainWindow : Window
    {
        public MainWindow()
        {
            InitializeComponent();
        }

        private void btnSearch_Click(object sender, RoutedEventArgs e)
        {
            try
            {
                RKEntities entities = new RKEntities().GetContext();//Получение контекста
                List<Student> students = entities.Student.Where(x => x.LastName == "Андрей" && x.FirstName == "Комаров").OrderByDescending(x => x.FirstName).ToList();//Получение списка студентов
                if(students.Count <=0)                                                                                                                                   //с отбором и сортировкой
                {//Если нет подходящих данных
                    MessageBox.Show("Подходящих данных не найдено!");
                }
                else
                {
                    string[,] data = new string[students.Count, 9];//Создаем массив с данными студентов
                    for (int i = 0; i < students.Count; i++)//Заполняем созданный массив данными
                    {                                       //заменяя внешние ключи на данные
                        data[i, 0] = students[i].IdStudent.ToString();
                        data[i, 1] = students[i].FirstName;
                        data[i, 2] = students[i].LastName;
                        data[i, 3] = students[i].Patronymic;
                        data[i, 4] = students[i].Email;
                        data[i, 5] = students[i].Telephone;
                        data[i, 6] = students[i].Group.Title;
                        data[i, 7] = students[i].Group.Speciality.Title;
                        data[i, 8] = students[i].StatusStudent.Title;
                    }
                    LoadData.DataContext = data;//Загружаем в DataGrid данные
                }
            }
            catch (Exception ex)//Если произошла ошибка, выводим её
            {
                MessageBox.Show(ex.Message);
            }
            
        }
    }
}
